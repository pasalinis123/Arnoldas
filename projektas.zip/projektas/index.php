<?php 
	require __DIR__ . '/app.php';
?>



<!DOCTYPE html>
<html lang="">
	<head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link rel="stylesheet" href="normalize.css">
			<link rel="stylesheet" href="style.css">
			<title>Baigiamasis projektas</title>
			<link rel="preconnect" href="https://fonts.gstatic.com">
			<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
			<script src="https://kit.fontawesome.com/2ed0aa7c2e.js" crossorigin="anonymous"></script>
	</head>

	<body>
		<!-- header -->
		<div class="header">
			<div class="container flex-container">
				<div class="logo">
					<img class="banner-1"src="images/logo/logo.png" alt="logo" class="Logo">
				</div>
				<nav class="nav-bar">
					<ul class="nav-bar flex-container">
						<a href="#"><li>Home</li></a>
						<a href="#"><li>About</li></a>
						<a href="#"><li>Blog</li></a>
						<a href="#"><li>Training</li></a>
						<a href="#"><li>Event</li></a>
						<a href="#"><li>Shop</li></a>
						<a href="#"><li>Contact</li></a>	
					</ul>
				</nav>
			</div>
		</div>
		<!-- banner 1 -->
		<section class="banner flex-container">
			<div class="column-left">
				<img src="images/banner_1/image_girl_03.png" alt="joga">
			</div>
			<div class="column-right">
				<h1>Balance Your <br>Body and Mind</h1>
				<p>Duis aute irure dolar in reprahenrit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat</p>
				<button type="button" class="button">join us now</button>
			</div>
		</section>
			<!-- banner 2 -->
		<section class="banner_2 flex-container">
			<div class="banner-2">
				<h2>Pregnant<br>women program</h2>
				<p>Duis aute irure dolor in reprehenderit in voluptate velit <br>esse cillum dolore eu fugiat nulla pariatur. Excepteur<br> sint occaecat cupidatat</p>
			</div>
			<div class="filler"></div>
		</section>
		<!-- 3 icon-banner -->
		<section class="icon-banner">
			<div class="container-icon flex-container">
				<div class="program-1">
					<img class="icon-1" src="images/Icon/icon_1.png" alt="program-1">
					<h2>Program 1</h2>
					<p>sint occaecat cupidatat non</p>
				</div>
				<div class="program-2">
					<img class="icon-2" src="images/Icon/icon_2.png" alt="program-1">
					<h2>Program 2</h2>
					<p>sint occaecat cupidatat non</p>
				</div>
				<div class="program-3">
					<img class="icon-3" src="images/Icon/icon_3.png" alt="program-1">
					<h2>Program 3</h2>
					<p>sint occaecat cupidatat non</p>
				</div>
			</div>
		</section>
		<!-- banner-4 -->
		<section class="banner-4">
			<div class="container flex-container">
				<div class="left-content">
					<h2>Yoga Breathing<br> or Pranayama</h2>
					<p>Duis aute irure dolor in reprehenderit in voluptate velit<br> esse cillum dolore eu fugiat nulla pariatur. Excepteur<br> sint occaecat cupidatat.</p>
				<button class="button" type="submit">Learn more</button>
				</div>
				<div class="right-content">
				<div class="lady-joga">
					<img src="images/banner_3/banner_3.jpg" alt="lady-joga">
				</div>
				</div>
			</div>
		</section>
		<!-- banner 5 -->
		<section class="banner-5">
			<div class="con-bann-5 flex-container">
				<div class="left-content-5">
					<img class="lady" src="images/banner_4/banner_4-1.png" alt="banner-5">
				</div>
				<div class="right-content-5">
					<h2>Join Now and<br> Get 50% OFF</h2>
					<p>Duis aute irure dolor in reprehenderit in voluptate velit <br>esse cillum dolore eu fugiat nulla pariatur. Excepteur<br> sint occaecat cupidatat.</p>
				</div>
			</div>
		</section>
		<!-- galery 6 -->
		<section class="galery-banner">
			<div class="galery">
				<div class="top-text">
					<h2>galery</h2>
					<p>Neque laoreet suspendisse interdum consectetur libero id faucibus nisl tincidunt. Dictum <br>fusce ut placerat orci nulla pellentesque dignissim enim sit. </p>
				</div>
				<div class="container">
				<div class="content-galery flex-container">
					<div class="image-1">
						<img src="images/banner_5/1_foto_banner_5.jpg" alt="banner-6">
						<div class="text">
						<h2>Facilis Gravida</h2>
						<p>A lacus vestibulum sed. Amet purus<br> gravida quis blandit turpis.</p>
						</div>
						</div>
					<div class="image-2">
						<img src="images/banner_5/2_foto_banner_5.jpg" alt="image-2">
						<div class="text">
						<h2>Facilis Gravida</h2>
						<p>A lacus vestibulum sed. Amet purus <br>gravida quis blandit turpis.</p>
						</div>
					</div>
					<div class="image-3">
						<img src="images/banner_5/3_foto_banner_5.jpg" alt="image-3">
						<div class="text"><h2>Facilis Gravida</h2>
						<p>A lacus vestibulum sed. Amet purus<br> gravida quis blandit turpis.</p></div>
					</div>
				</div>
				</div>
				
			</div>
		</section>
		<!--  8 Subscribe -->
		<section class="subscribe">
			<div class="subcribe-text">
				<h2>Get in Touch</h2>
				<p>Neque laoreet suspendisse interdum consectetur libero id faucibus nisl tincidunt. Dictum<br> fusce ut placerat orci nulla pellentesque dignissim enim sit. </p>
			</div>
			<form id="contact" action="index.php" method="post">
				<input class="your-name" type="text" name="vardas" placeholder="Your Name" required autofocus>
				<input class="email" type="email" name="email" placeholder="Email" required>
				<input class="message" type="text" name="message" placeholder="Your Message" required>
				<button id="contact-submit" class="button" type="submit" name="submit">Send Message</button>
			</form>
		</section>
		<!-- 9 footer -->
		<footer class="footer">
			<div class="container flex-container">
				<div class="column-1">
					<h3>Baigiamasis projektas</h3>
					<p>Halimun Street 25<br>Jakarta, Indonesia<br>12850</p>
				</div>
				<div class="column-2">
					<a href="#">Home</a>
					<a href="#">About</a>
					<a href="#">Blog</a>
					<a href="#">Menu</a>
					<a href="#">Store</a>
					<a href="#">Contact</a>
				</div>
				<div class="column-3">
					<img src="images/logo/logo_footer_03.png" alt="logo-footer">
					<p>Copyright   &copy;<?php echo date('Y');?> Freepik<br>
Company S.L. All rights reserved.</p>
					<div class="social-media">
					<img class="facebook" src="images/social_media/facebook.png" alt="facebook">
					<img class="instagram" src="images/social_media/instagram.png" alt="instagram-icon">
					<img class="twitter" src="images/social_media/twitter.png" alt="twitter-icon">
				</div>
				</div>
				
			</div>
			
				
		
		</footer>
				
			
	
	</body>
</html>
